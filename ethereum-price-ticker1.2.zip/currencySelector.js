app.controller("currencySelectorCtrl", function(chromeStoreFactory, $scope) {
	var self = this;

	this.currencyOptions = chromeStoreFactory.currencyOptions;

	chromeStoreFactory.getCurrency().then(function(){
		$scope.$apply(function(){
			self.selectedCurrency = chromeStoreFactory.currency;
			self.getCurrentPrice();
		});
	});

	this.saveCurrencyChoice = function(){
		chromeStoreFactory.setCurrency(self.selectedCurrency);
		self.getCurrentPrice();
	};

	this.getCurrentPrice = function(){
		self.currentPrice = "Loading...";
		$.get(self.getUrl(), function(response){
			var valueAsNumber = Number(response[chromeStoreFactory.currency]);
			chrome.browserAction.setBadgeText({text: valueAsNumber.toString()});
			$scope.$apply(function(){
				if(self.selectedCurrency != "BTC"){
					self.currentPrice = (valueAsNumber).toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2, minimumFractionDigits: 2 });
				}
				else{
					self.currentPrice = valueAsNumber.toString();
				}
			});
		});
	};

	this.getUrl = function(){
		return "https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=" + chromeStoreFactory.currencyOptions.join(",") + "&e=Coinbase";
	};
});
