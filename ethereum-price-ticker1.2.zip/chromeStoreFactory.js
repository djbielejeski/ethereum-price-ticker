app.factory("chromeStoreFactory", function () {
	var self = this;
	this.currencyOptions = ["USD", "EUR", "BTC"];

	this.getCurrency = function() {
		return new Promise(function (resolve, reject) {
			chrome.storage.sync.get('currency', function (data) {
				if (data.currency) {
					self.data.currency = data.currency;
				} else {
					chrome.storage.sync.set({'currency': self.currencyOptions[0]});
					self.data.currency = self.currencyOptions[0];
				}

				resolve();
			});
		});
	};


	this.setCurrency = function(currency){
		chrome.storage.sync.set({ 'currency': currency});
		self.data.currency = currency;
	};

	this.data = {
		currencyOptions: self.currencyOptions,
		getCurrency: self.getCurrency,
		setCurrency: self.setCurrency,
		currency: ""
	};

	return self.data;
});