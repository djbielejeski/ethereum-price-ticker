app.controller("getPriceCtrl", function(chromeStoreFactory, $interval) {
	var self = this;
	this.getCurrentPrice = function(){
		$.get(self.getUrl(), function(response){
			var valueAsNumber = Number(response[chromeStoreFactory.currency]);
			chrome.browserAction.setBadgeText({text: valueAsNumber.toString()});
		});
	};

	this.getUrl = function(){
		return "https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=" + chromeStoreFactory.currencyOptions.join(",") + "&e=Coinbase";
	};

	chromeStoreFactory.getCurrency().then(function(){
		$interval(self.getCurrentPrice, 10000);
		$interval(chromeStoreFactory.getCurrency, 2000);
	});

});
