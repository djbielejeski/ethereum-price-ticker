(function() {
    setInterval(function() {
        getPrice();
    }, 20000);
})();
